﻿namespace SchoolBridge.Domain.Services.Abstraction
{
    public interface IMyService
    {
    }
}
