﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SchoolBridge.Domain.Services.Abstraction
{
    public interface IOnFirstInitService: IMyService
    {
    }
}
