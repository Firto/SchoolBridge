﻿using SchoolBridge.Domain.Services.Implementation;

namespace SchoolBridge.Domain.Services.Abstraction
{
    public interface IOnInitService: IMyService
    {
        
    }
}
