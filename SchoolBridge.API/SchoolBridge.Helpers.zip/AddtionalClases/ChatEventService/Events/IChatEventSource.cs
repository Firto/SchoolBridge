﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SchoolBridge.Helpers.AddtionalClases.ChatEventService.Events
{
    public interface IChatEventSource
    {
    }
}
