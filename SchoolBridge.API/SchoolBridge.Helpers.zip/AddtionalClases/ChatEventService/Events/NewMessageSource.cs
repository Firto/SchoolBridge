﻿using SchoolBridge.Helpers.AddtionalClases.DataBaseNotoficationService.ChatSources;
using SchoolBridge.Helpers.DtoModels;
using SchoolBridge.Helpers.DtoModels.Chat;
using System;
using System.Collections.Generic;
using System.Text;

namespace SchoolBridge.Helpers.AddtionalClases.ChatEventService.Events
{
    public class NewMessageSource: MessageDto, IChatEventSource
    {
        
    }
}