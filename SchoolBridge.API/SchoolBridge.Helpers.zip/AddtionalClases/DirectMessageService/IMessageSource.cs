﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SchoolBridge.Helpers.AddtionalClases.DirectMessageService
{
    public interface IMessageSource
    {
    }
}
