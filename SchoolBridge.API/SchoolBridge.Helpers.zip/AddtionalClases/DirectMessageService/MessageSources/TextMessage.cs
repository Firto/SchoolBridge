﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SchoolBridge.Helpers.AddtionalClases.DirectMessageService.MessageSources
{
    public class TextMessage: IMessageSource
    {
        public string Text { get; set; }
    }
}
