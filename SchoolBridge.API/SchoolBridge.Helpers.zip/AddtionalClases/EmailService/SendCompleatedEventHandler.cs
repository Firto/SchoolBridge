﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SchoolBridge.Helpers.AddtionalClases.EmailService
{
    public delegate void SendCompleatedEventHandler(EmailSendCompleatedEntity entity);
}
