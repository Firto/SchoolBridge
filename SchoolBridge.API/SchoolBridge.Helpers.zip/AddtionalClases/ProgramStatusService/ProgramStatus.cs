﻿using System;

namespace SchoolBridge.Helpers.AddtionalClases.ProgramStatusService
{
    public class ProgramStatus
    {
        public Boolean IsLoadedFirst { get; set; } = true;
    }
}
