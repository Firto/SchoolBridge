﻿namespace SchoolBridge.Helpers.AddtionalClases.DataBaseNotoficationService
{
    public interface IDataBaseNotificationSourse { }
}