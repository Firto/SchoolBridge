﻿namespace SchoolBridge.Helpers.AddtionalClases.DataBaseNotoficationService
{
    public class MessageNotificationSource : IDataBaseNotificationSourse
    {
        public string Message { get; set; }
    }
}
