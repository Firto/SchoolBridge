﻿using SchoolBridge.Helpers.DtoModels.Chat;
using System;
using System.Collections.Generic;
using System.Text;

namespace SchoolBridge.Helpers.AddtionalClases.DataBaseNotoficationService.ChatSources
{
    public class ChatMessageSource: MessageDto, IDataBaseNotificationSourse
    {
        
    }
}
