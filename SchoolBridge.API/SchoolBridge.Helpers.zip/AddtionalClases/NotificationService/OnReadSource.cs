﻿namespace SchoolBridge.Helpers.AddtionalClases.NotificationService
{
    public class OnReadSource : INotificationSource
    {
        public string Last { get; set; }
        public int Count { get; set; }
    }
}