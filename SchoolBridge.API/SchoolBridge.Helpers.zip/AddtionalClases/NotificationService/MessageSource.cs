﻿namespace SchoolBridge.Helpers.AddtionalClases.NotificationService
{
    public class MessageSource : INotificationSource
    {
        public string Message { get; set; }
    }
}