﻿namespace SchoolBridge.Helpers.AddtionalClases.NotificationService
{
    public interface INotificationSource { }
}