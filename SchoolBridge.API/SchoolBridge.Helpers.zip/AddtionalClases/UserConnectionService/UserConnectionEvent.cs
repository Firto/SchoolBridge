﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace SchoolBridge.Helpers.AddtionalClases.UserConnectionService
{
    public delegate Task UserConnectionEvent(UserSession session);
}
