﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SchoolBridge.Helpers.AddtionalClases.OnlineService
{
    public enum OnlineStatus
    {
        Offline = 0,
        Online,
        Hide
    }
}
