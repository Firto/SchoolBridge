﻿namespace SchoolBridge.Helpers.DtoModels.Authefication
{
    public class RefreshTokenDto
    {
        public string RefreshToken { get; set; }
    }
}
