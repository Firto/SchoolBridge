﻿namespace SchoolBridge.Helpers.DtoModels.ClientErrors.Info
{
    public class ClientErrorInfoDto 
    {
        public string Description { get; set; }
    }
}