﻿namespace SchoolBridge.Helpers.DtoModels.ClientErrors
{
    public class ClientErrorDto
    {
        public string Id { get; set; }
        public string Message { get; set; }
    }
}