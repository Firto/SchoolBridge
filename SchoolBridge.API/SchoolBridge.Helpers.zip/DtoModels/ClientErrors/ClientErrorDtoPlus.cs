﻿namespace SchoolBridge.Helpers.DtoModels.ClientErrors
{
    public class ClientErrorDtoPlus : ClientErrorDto
    {
        public object AdditionalInfo { get; set; }
    }
}