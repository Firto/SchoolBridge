﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SchoolBridge.Helpers.DtoModels
{
    public class ShortUserDto
    {
        public string Id { get; set; }
        public UserGetToken GetToken { get; set; }
    }
}
